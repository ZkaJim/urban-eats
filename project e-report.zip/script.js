const body = document.getElementById('theMeal');

const getData = async () => {
    try {
        const response = await fetch('https://www.themealdb.com/api/json/v1/1/categories.php');
        const res = await response.json();

        console.log (res)
        const resMap = res.categories.map((item) => {
            return `
            <div>
                <h2>${item.strCategory}</h2>
                <img src="${item.strCategoryThumb}" alt="${item.strCategory}" width="200" height="200">
                <p>${item.strCategoryDescription}</p>
            </div>
            `
        })

        body.innerHTML = resMap.join('');
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

getData();